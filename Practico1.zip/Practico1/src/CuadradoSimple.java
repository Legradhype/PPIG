import java.awt.*;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

public class CuadradoSimple {
    private int tamano;
    private Color color;
    private int x;
    private int y;
    private final PropertyChangeSupport support;

    public CuadradoSimple(int tamano, Color color, int x, int y) {
        this.tamano = tamano;
        this.color = color;
        this.x = x;
        this.y = y;
        this.support = new PropertyChangeSupport(this);
    }

    public int getTamano() {
        return tamano;
    }

    public Color getColor() {
        return color;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        int oldX = this.x;
        this.x = x;
        support.firePropertyChange("POSICION", new Point(oldX, y), new Point(x, y));
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        int oldY = this.y;
        this.y = y;
        support.firePropertyChange("POSICION", new Point(x, oldY), new Point(x, y));
    }

    public void addObserver(PropertyChangeListener listener) {
        support.addPropertyChangeListener(listener);
    }
}
