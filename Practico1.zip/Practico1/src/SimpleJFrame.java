import javax.swing.*;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;

public class SimpleJFrame extends JFrame {
    private static final Logger logger = LogManager.getLogger(SimpleJFrame.class);
    private long startTime;
    private JLabel mensaje;
    private SimpleJPanel panel1;
    private SimpleJPanel panel2;
    private SimpleJPanel target1;
    private SimpleJPanel target2;
    private ArrayList<Long> scores = new ArrayList<>();

    public SimpleJFrame() {
        setTitle("Juego de Cuadrados");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Crear el menú bar
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Opciones");

        JMenuItem nuevoItem = new JMenuItem("Nuevo");
        nuevoItem.addActionListener(e -> startNewGame());
        menu.add(nuevoItem);

        JMenuItem scoresItem = new JMenuItem("Scores");
        scoresItem.addActionListener(e -> showScores());
        menu.add(scoresItem);

        JMenuItem salirItem = new JMenuItem("Salir");
        salirItem.addActionListener(e -> System.exit(0));
        menu.add(salirItem);

        menuBar.add(menu);
        setJMenuBar(menuBar);

        // Inicializar el juego
        startNewGame();
    }

    private void startNewGame() {
        getContentPane().removeAll();
        repaint();

        // Crear los cuadrados vacíos con bordes (posicionados con más distancia)
        target1 = new SimpleJPanel(null, null, Color.BLUE, true, 100, 100); // Fila 1, Columna 1
        target2 = new SimpleJPanel(null, null, Color.RED, true, 400, 100);  // Fila 1, Columna 2
        add(target1);
        add(target2);

        // Crear los cuadrados coloridos para arrastrar (posicionados con más distancia)
        CuadradoSimple modelo1 = new CuadradoSimple(50, Color.BLUE, 100, 400); // Fila 2, Columna 1
        CuadradoSimple modelo2 = new CuadradoSimple(50, Color.RED, 400, 400);  // Fila 2, Columna 2
        panel1 = new SimpleJPanel(modelo1, target1, Color.BLUE, false, modelo1.getX(), modelo1.getY());
        panel2 = new SimpleJPanel(modelo2, target2, Color.RED, false, modelo2.getX(), modelo2.getY());
        add(panel1);
        add(panel2);

        // Mensaje en la parte inferior
        mensaje = new JLabel("Arrastra los cuadrados a las posiciones vacías.");
        mensaje.setBounds(10, 500, 580, 30);
        add(mensaje);

        startTime = System.currentTimeMillis();

        setVisible(true);
    }

    public void checkWinCondition() {
        if (target1.isFilled() && target2.isFilled()) {
            long endTime = System.currentTimeMillis();
            long elapsedTime = endTime - startTime;
            scores.add(elapsedTime);
            JOptionPane.showMessageDialog(this, "¡Lo lograste en " + (elapsedTime / 1000.0) + " segundos!", "Felicitaciones", JOptionPane.INFORMATION_MESSAGE);
            logger.info("Juego completado en " + (elapsedTime / 1000.0) + " segundos.");
            startNewGame();
        }
    }

    private void showScores() {
        Collections.sort(scores);
        StringBuilder scoreList = new StringBuilder("Scores (de menor a mayor):\n");
        for (Long score : scores) {
            scoreList.append(score / 1000.0).append(" segundos\n");
        }
        JOptionPane.showMessageDialog(this, scoreList.toString(), "Scores", JOptionPane.INFORMATION_MESSAGE);
    }
}
