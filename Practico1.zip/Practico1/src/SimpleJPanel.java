import javax.swing.*;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class SimpleJPanel extends JPanel implements PropertyChangeListener {
    private static final Logger logger = LogManager.getRootLogger();
    private final CuadradoSimple modelo;
    private final SimpleJPanel target;
    private boolean filled;
    private Point initialClick;

    // Constructor para cuadrados coloridos
    public SimpleJPanel(CuadradoSimple modelo, SimpleJPanel target, Color color, boolean isTarget, int x, int y) {
        this.modelo = modelo;
        this.target = target;
        this.filled = false;

        if (!isTarget) {
            this.modelo.addObserver(this);
            setBounds(x, y, 100, 100);
            setBackground(color);
            addMouseListeners();
        } else {
            setBounds(x, y, 100, 100);
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createLineBorder(color, 5));
        }
    }

    // Constructor para cuadrados vacíos (target)
    public SimpleJPanel(int x, int y, Color borderColor) {
        this(null, null, borderColor, true, x, y);
    }

    private void addMouseListeners() {
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                initialClick = e.getPoint();
                // Traer el cuadrado arrastrado al frente
                getParent().setComponentZOrder(SimpleJPanel.this, 0);
                repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (getBounds().intersects(target.getBounds())) {
                    target.setBackground(modelo.getColor()); // El target adopta el color del cuadrado arrastrado
                    setVisible(false); // Ocultar el cuadrado colorido después de colocarlo
                    target.setFilled(true);
                    ((SimpleJFrame) SwingUtilities.getWindowAncestor(SimpleJPanel.this)).checkWinCondition();
                } else {
                    setLocation(modelo.getX(), modelo.getY());
                }
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int thisX = getLocation().x;
                int thisY = getLocation().y;

                int xMoved = e.getX() - initialClick.x;
                int yMoved = e.getY() - initialClick.y;

                int newX = thisX + xMoved;
                int newY = thisY + yMoved;

                setLocation(newX, newY);
                modelo.setX(newX);
                modelo.setY(newY);
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (modelo != null) {
            g.setColor(modelo.getColor());
            g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
        }
        logger.info("Dibujo cuadrado en " + (modelo != null ? modelo.getX() + "," + modelo.getY() : getX() + "," + getY()));
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if ("POSICION".equals(evt.getPropertyName())) {
            setLocation(modelo.getX(), modelo.getY());
        } else if ("COLOR".equals(evt.getPropertyName())) {
            repaint();
        }
    }
}
