import javax.swing.*;
import java.awt.*;

public class TargetSquare extends JPanel {
    private boolean filled;

    public TargetSquare(int x, int y, Color borderColor) {
        setBounds(x, y, 100, 100);
        setBorder(BorderFactory.createLineBorder(borderColor, 5));
        filled = false;
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
        setBackground(filled ? Color.LIGHT_GRAY : Color.WHITE);
    }
}
