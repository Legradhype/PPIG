import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.awt.*;

public class VistaCuadradoSimple {
    private static final Logger logger = LogManager.getRootLogger();
    private final CuadradoSimple modelo;

    public VistaCuadradoSimple(CuadradoSimple m) {
        modelo = m;
    }

    public void dibujar(Graphics g) {
        g.setColor(modelo.getColor());
        g.drawRect(modelo.getX(), modelo.getY(), modelo.getTamano(), modelo.getTamano());
        logger.info("Dibujo figura en " + modelo.getX() + "," + modelo.getY() + " con tamano " + modelo.getTamano());
    }
}

