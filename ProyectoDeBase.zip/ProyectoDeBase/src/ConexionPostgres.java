import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionPostgres {
    private static final String URL = "jdbc:postgresql://localhost:5432/Gestion_de_vehiculos"; // Cambia por tu URL y nombre de base de datos
    private static final String USER = "postgres"; // Cambia por tu usuario de PostgreSQL
    private static final String PASSWORD = "root"; // Cambia por tu contraseña

    public static Connection conectar() {
        Connection connection = null;
        try {
            // Establecer la conexión con PostgreSQL
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos");
        } catch (SQLException e) {
            System.err.println("Error al conectar con la base de datos: " + e.getMessage());
        }
        return connection;
    }
}
