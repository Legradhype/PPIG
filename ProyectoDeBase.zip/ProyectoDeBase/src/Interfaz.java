import javax.swing.*;
import java.sql.*;

public class Interfaz {
    public static void main(String[] args) {
        // Llamamos a la conexión a la base de datos
        Connection connection = ConexionPostgres.conectar();

        if (connection != null) {
            mostrarTablas(connection);
        } else {
            JOptionPane.showMessageDialog(null, "No se pudo conectar a la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para mostrar las tablas de la base de datos
    public static void mostrarTablas(Connection connection) {
        try {
            // Ejecutamos una consulta para obtener las tablas de la base de datos
            DatabaseMetaData metaData = connection.getMetaData();
            ResultSet resultSet = metaData.getTables(null, null, "%", new String[] {"TABLE"});

            StringBuilder tablas = new StringBuilder();

            // Recorremos el resultado y almacenamos los nombres de las tablas
            while (resultSet.next()) {
                String tableName = resultSet.getString("TABLE_NAME");
                tablas.append(tableName).append("\n");
            }

            // Mostramos las tablas en un cuadro de mensaje
            if (tablas.length() > 0) {
                JOptionPane.showMessageDialog(null, "Tablas en la base de datos:\n" + tablas.toString(), "Tablas", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontraron tablas", "Sin resultados", JOptionPane.INFORMATION_MESSAGE);
            }

            // Cerramos el resultSet
            resultSet.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener las tablas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
