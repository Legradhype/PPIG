public class Main {
    public static void main(String[] args) {
        // Mostrar mensaje en consola
        System.out.println("Hello world!");

        // Llamar a la clase de conexión y obtener la conexión
        ConexionPostgres.conectar();
    }
}
